import React from 'react'
import './Style/nav-style.css'
const Nav = () => {
  return (
    <div>
      <ul>
  <li>Home</li>
  <li>News</li>
  <li>Contact</li>
  <li>About</li>
</ul>
    </div>
  )
}

export default Nav
