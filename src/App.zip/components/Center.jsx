import React from 'react'

const Center = () => {
  return (
    <div>
      <h1>good morning</h1>
    </div>
  )
}

export default Center
